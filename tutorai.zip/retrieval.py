import faiss
import pickle
import json
import textwrap
from sentence_transformers import SentenceTransformer
from langdetect import detect
from deep_translator import GoogleTranslator
from sklearn.metrics.pairwise import cosine_similarity

# === Load FAISS index ===
index = faiss.read_index("wbs_faiss.index")

# === Load metadata chunks ===
with open("wbs_metadata.pkl", "rb") as f:
    metadata = pickle.load(f)

# === Load model embedding ===
model = SentenceTransformer("intfloat/e5-base-v2")

# === Deteksi dan translasi pertanyaan ===
def translate_if_needed(text, target_lang="en"):
    try:
        lang = detect(text)
    except:
        lang = "unknown"
    if lang == "id" and target_lang == "en":
        translated = GoogleTranslator(source='id', target='en').translate(text)
        return translated, "id"
    else:
        return text, lang

# === Retrieve top-k context ===
def retrieve_context(user_question, top_k=5, similarity_threshold=0.80, min_chunk_length=100):
    # Translate jika perlu
    question_translated, detected_lang = translate_if_needed(user_question)

    # Buat embedding dari pertanyaan
    question_embedding = model.encode([question_translated], convert_to_numpy=True)

    # FAISS search
    distances, indices = index.search(question_embedding, top_k)

    # Hitung similarity terhadap seluruh indeks
    all_embeddings = index.reconstruct_n(0, index.ntotal)
    similarities = cosine_similarity(question_embedding, all_embeddings)[0]

    # Ambil index dari hasil search
    top_indices = indices[0]

    print("\n🔍 Skor Kemiripan Chunk:")
    for i, idx in enumerate(top_indices):
        print(f"Chunk {i+1}: index {idx} | similarity: {similarities[idx]:.4f}")

    # Filter hasil berdasarkan threshold similarity dan panjang isi chunk
    final_chunks = []
    for idx in top_indices:
        chunk = metadata[idx]
        if similarities[idx] >= similarity_threshold and len(chunk["content"].strip()) >= min_chunk_length:
            final_chunks.append(chunk)

    # Jika semua chunk ke-filter, fallback ambil chunk teratas
    if not final_chunks:
        print("\n⚠️ Tidak ada chunk lolos filter, menggunakan hasil asli...")
        final_chunks = [metadata[i] for i in top_indices]

    print("\n🔍 Debug Hasil Retrieval:")
    for i, item in enumerate(final_chunks):
        print(f"\n--- Chunk {i+1} dari {item['source']} ---")
        print(textwrap.fill(item['content'], width=100))

    return final_chunks, detected_lang